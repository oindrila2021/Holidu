package Utilities;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.HashMap;
import java.util.Map;

public class ReadFile {
	
	//File path to be changed according to the location of workspace
		final static String filePath = "C:\\Users\\Oindr\\selenium_Java_project\\FirstTestNGProject\\data\\data.txt";
		
		public static Map<String, String> getDataValue()
		{
			Map<String, String> fileContent = new HashMap<String, String>();
			BufferedReader br = null;
			
			try {
				
				File file = new File(filePath);
				br = new BufferedReader(new FileReader(file));
				String line = null;
				
				while( (line = br.readLine()) != null)
				{
					String [] content = line.split(":");
					String key = content[0].trim();
					String value = content[1].trim();
					
					if(!key.equals("") && !value.equals(""))
					{
						fileContent.put(key, value);
					}
							
				}
				
			}
			catch (Exception e)
			{
				e.printStackTrace();
			}
			finally {
				if(br != null)
				{
					try {
						br.close();
					}
					catch(Exception e)
					{
						e.printStackTrace();
					}
				}
			}
			
			return fileContent;
		}
		

}
