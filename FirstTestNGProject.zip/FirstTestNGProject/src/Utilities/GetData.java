package Utilities;

import java.util.Map;

public class GetData {

	Map<String,String> m ;
	private String searchlocation;
	
	public GetData()
	{
		m = Utilities.ReadFile.getDataValue();
		searchlocation = m.get("searchLocation");
		
	}
	
	public String getlocatio()
	{
		return searchlocation;
	}
	
	public void setlocation(String searchlocation) {
		this.searchlocation = searchlocation;
	  }
}
