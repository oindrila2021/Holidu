package Utilities;

import org.openqa.selenium.WebDriver;

public class Driver {
	
	protected static WebDriver driver;
	
	public void setWebdriver(WebDriver driver)
	{
		Driver.driver = driver;
	}

}
