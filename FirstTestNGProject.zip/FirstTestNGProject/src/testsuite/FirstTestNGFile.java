package testsuite;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pages.homepage;
import pages.openURLPage;

public class FirstTestNGFile {
		
	@BeforeTest
	public void setup() {
		openURLPage.openUrl();
	}
	
	@Test
	public void verifySearch() {
		homepage obj = new homepage();
		obj.searchForLocation();	
		obj.fromDate();
		obj.seekButton();
		obj.stayType();
		obj.assertSearchTitle();
	}
	
	@AfterTest
	public void teardown() {
		openURLPage.tearDown();
	}
	
	
  
}
