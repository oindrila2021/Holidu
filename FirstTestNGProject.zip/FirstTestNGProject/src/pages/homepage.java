package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import Utilities.Driver;
import Utilities.GetData;

public class homepage extends Driver {

	public static WebElement searchlocation;
	GetData data = new GetData();
	
	public void searchForLocation()
	{
		String location = data.getlocatio();		
		searchlocation = driver.findElement(By.xpath("//*[@placeholder='Reiseziel eingeben']"));
		searchlocation.sendKeys(location);
	}
	
	public void seekButton() {
		
		driver.findElement(By.xpath("//*[@class='SearchButton css-18d8x6h']")).click();
	}
	
	public void toDate() {
		driver.findElement(By.xpath(" //div[contains(text(),'Abreise')]")).click();
		driver.findElement(By.xpath("//body/main[@id='main']/div[@id='root']/div[1]/section[1]/div[1]/div[1]/div[1]/div[3]/div[1]/div[3]/div[1]/div[1]/div[2]/div[2]/div[3]/div[4]/div[2]/div[1]")).click();
	}
	public void fromDate() {
		driver.findElement(By.xpath("//div[contains(text(),'Anreise')]")).click();
		driver.findElement(By.xpath("//body/main[@id='main']/div[@id='root']/article[@id='article']/section[1]/div[1]/div[3]/div[1]/div[1]/div[3]/div[1]/div[3]/div[2]/div[1]/div[2]/div[2]/div[2]/div[7]/div[2]/div[1]")).click();
	}
	
	public void stayType() {
		driver.findElement(By.xpath("//body/main[@id='main']/div[@id='root']/div[1]/article[1]/div[1]/div[1]/div[1]/div[1]/div[3]/div[1]/button[7]/div[1]")).click();
	}
	
	public void assertSearchTitle() {
		String searchTitle = driver.findElement(By.xpath("//*[contains(text(),'Nordsee, Deutschland: 27 Unterk�nfte gefunden')]")).getText();
		String actualText = "Nordsee, Deutschland: 27 Unterk�nfte gefunden";
		Assert.assertEquals(searchTitle.toLowerCase(), actualText.toLowerCase());
	}
}

