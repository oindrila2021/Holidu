package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import Utilities.Driver;

public class openURLPage {

	private static WebDriver driver;
	//protected static loginPage login;
	protected static Driver driverpage;
	public static void openUrl(){	
		
		System.setProperty("webdriver.crome.drive", "D:\\chromedriver.exe");
		
		System.setProperty("webdriver.gecko.driver", "C:\\Program Files\\geckodriver.exe");
		
		driver = new FirefoxDriver();
		
		driver.get("https://www.holidu.de/");
		
		driver.manage().window().maximize();
		//login = new loginPage();		
		//login.setWebdriver(driver);
		
		driverpage = new Driver();
		driverpage.setWebdriver(driver);
	}
	
	public static void tearDown() {
		
		driver.close();
	}
}
